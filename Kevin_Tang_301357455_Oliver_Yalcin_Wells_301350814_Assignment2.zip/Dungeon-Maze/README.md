# Dungeon-Maze
Created for assignment 2 in the CMPT 213 course of the SFU Computing Science Program.

- A command console game where you play as a hero exploring a labyrinth crawling with monsters 
- You must kill all monsters in order to win
- Features randomly generated mazes on every bootup, as well as monsters with simple AI
- Based on a object-oriented framework that can support extensive modding.
